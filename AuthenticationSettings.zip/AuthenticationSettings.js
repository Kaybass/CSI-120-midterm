twitterInfo = {
accessToken: '416744660-80rtfPAJozrhtxJxMRJ59dvvn1ZXCbLv3sH8PUjp',
accessTokenSecret: '416744660-80rtfPAJozrhtxJxMRJ59dvvn1ZXCbLv3sH8PUjp',
consumerKey: 'HGOvd84clRvWaiGLVfsdpA',
consumerSecret: '2BKlskG82sOKCa0zkXkZ1gSsyxYbgj96lOhkdcHk'
}